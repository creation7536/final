from pymongo import MongoClient
import threading
import time
import random
from pprint import pprint



class Philosopher(threading.Thread):
    threading.running=True
    connection=MongoClient("mongodb://127.0.0.1:27017")
    counter=0
    @staticmethod
    def readFromMongo(id,Name):
        print("%s Thinking"%Name)
        db=Philosopher.connection.test.TempData
        limit=Philosopher.counter
        record=db.find({"ph_no":id})[limit:limit+1]
        for doc in record: pprint(doc)
        Philosopher.counter+=1
        Philosopher.counter%=9


        


    def __init__(self,index,name,left,right):
        threading.Thread.__init__(self)
        self.id=index
        self.Name=name
        self.LeftFork=left
        self.RightFork=right
    
    def run(self):
        while(self.running):
            time.sleep(random.uniform(3,13))
            print("%s is Hungry"%self.Name)
            self.dine()

    def dine(self):
        while(self.running):
            fork1,fork2=self.LeftFork,self.RightFork
            fork1.acquire(True)
            locked=fork2.acquire(False)
            if locked: break
            fork1.release()
            #swap the forks
            fork1,fork2=fork2,fork1

        else:
            return
        
        self.dining()
        fork1.release()
        fork2.release()
    
    def dining(self):
        print("%s starts Eating"%self.Name)
        Philosopher.readFromMongo(self.id,self.Name)
        time.sleep(random.uniform(3,13))
        print("%s Finished Eating"%self.Name)


def DiningPhilosopher():
    forks=[threading.Lock() for i in range(5)]
    PhilosopherName=['Sheldon','Rajesh','howard','leonard','penny']

    philosophers=[Philosopher(i,PhilosopherName[i],forks[i%5],forks[(i+1)%5])for i in range(5)]

    Philosopher.running=True
    for i in range(5): philosophers[i].start()
    time.sleep(50)
    Philosopher.running=False

DiningPhilosopher()


    
