from flask import *
app =Flask(__name__)

@app.route('/')
def root():
	return render_template('myindex.html')

@app.route('/check',methods=['POST'])
def check():
	score = str(checker(request.form['string']))
	print 'SCORE:\t',score
	return render_template('myindex.html',msg=score)


def checker(msg_string):
	with open('data.txt','r') as f:
		file_data = ''
		for line in f:
			file_data += line
		file_data = clean_it(file_data)
		#print " file_data:",file_data

		#print '\n'
		string_data=clean_it(msg_string)
		#print " string_data:",string_data
		set_file_data = set(file_data)
		set_string_data = set(string_data)
		print set_file_data,'\n'+str(len(set_file_data))
		print set_string_data,'\n'+str(len(set_string_data))
		len_common =  len(list(set_string_data & set_file_data))
		#return '54'
		score = float(len_common) / len(set_file_data)*100
		print score
		#score= (float(len(list((set(file_data)&set(string_data))))) / len(file_data))*100
		return score

def clean_it(stri):
	stri=stri.replace(',','')
	stri=stri.replace('.','')
	stri=stri.replace('\n','')
	stri =stri.lower()
	stri = stri.split(' ')
	return stri








if __name__ == '__main__':
	app.run()